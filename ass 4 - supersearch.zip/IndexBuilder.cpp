#include "IndexBuilder.h"
#include "porter2_stemmer.h"

#include <algorithm>
#include <sstream>
#include <set>

// We'll load this from another file another time.
extern std::set<std::string> stopwords;

InvertedIndex IndexBuilder::build(const std::vector<Document>& docs) {
    InvertedIndex index;
    for (const auto& doc : docs) {
        indexDocument(index, doc);
    }
    return index;
}

std::vector<std::string> IndexBuilder::tokenize(const std::string& content) {
    std::vector<std::string> tokens;
    std::istringstream iss(content);
    std::string token;
    while (iss >> token) {
        std::transform(token.begin(), token.end(), token.begin(), ::tolower);
        tokens.push_back(token);
    }
    return tokens;
}

void IndexBuilder::removeStopwords(std::vector<std::string>& tokens) {
    tokens.erase(
        std::remove_if(tokens.begin(), tokens.end(), 
                       [](const std::string& token) { return stopwords.count(token) > 0; }),
        tokens.end());
}

void IndexBuilder::stem(std::vector<std::string>& tokens) {
    for (auto& token : tokens) {
        Porter2Stemmer::stem(token);
    }
}

void IndexBuilder::indexDocument(InvertedIndex& index, const Document& doc) {
    auto tokens = tokenize(doc.getContent());
    removeStopwords(tokens);
    stem(tokens);

    for (const auto& token : tokens) {
        index.addTerm(token, doc.getUuid());
    }

    // Assuming Document class has methods to get organizations and persons
    for (const auto& org : doc.getOrganizations()) {
        index.addOrganization(org.name, doc.getUuid());
    }
    for (const auto& person : doc.getPersons()) {
        index.addPerson(person.name, doc.getUuid());
    }
}