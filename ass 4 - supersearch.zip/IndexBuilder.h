#ifndef INDEX_BUILDER_H
#define INDEX_BUILDER_H

#include <string>
#include <vector>
#include "Document.h"
#include "inverted_index.h"

class IndexBuilder {
public:
    InvertedIndex build(const std::vector<Document>& docs);

private:
    std::vector<std::string> tokenize(const std::string& content);
    void removeStopwords(std::vector<std::string>& tokens);
    void stem(std::vector<std::string>& tokens);
    void indexDocument(InvertedIndex& index, const Document& doc);
};

#endif // INDEX_BUILDER_H